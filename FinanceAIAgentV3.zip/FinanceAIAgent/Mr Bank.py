# Mr Bank
# AI ChatBot V2

import random

KNOWN_TOPICS = {
    "greeting": ["hello", "hi", "hey"],
    "loan": ["loan", "borrow", "credit"],
    "income": ["income", "salary", "earnings"],
    "score": ["credit score", "credit rating", "score"],
    "exit": ["bye", "exit", "quit"]
}

HINTS = [
    "try saying 'check eligibility'",
    "ask about 'loan approval'",
    "say 'credit history info'",
    "type 'bye' to exit"
]

def predict_eligibility(model):
    try:
        print("\nLet's check your loan eligibility.")
        income = float(input("Enter your monthly income (£): "))
        co_income = float(input("Enter your coapplicant's income (£): "))
        loan_amt = float(input("Enter desired loan amount (£): "))
        loan_term = float(input("Enter loan term in months: "))
        credit_hist = int(input("Do you have a positive credit history? (1 = Yes, 0 = No): "))
        education = int(input("Are you a graduate? (1 = Yes, 0 = No): "))
        employment = int(input("Are you employed? (1 = Yes, 0 = No): "))
        property_area = int(input("Property area (0 = Rural, 1 = Semiurban, 2 = Urban): "))
        age = int(input("Enter your age: "))

        # Predict
        features = [[income, co_income, loan_amt, loan_term, credit_hist,
                     education, employment, property_area, age]]
        prediction = model.predict(features)[0]

        result = "Approved ✅" if prediction == 1 else "Not Approved ❌"
        print(f"\nPrediction: {result}")
        if prediction == 1:
            print("Based on your details, you meet our estimated loan approval criteria.")
        else:
            print("Your current details suggest loan approval is less likely.")
        print()
    except Exception as e:
        print(f"Error: {e}")
        print("Please ensure all values are entered correctly.\n")

def get_response(user_input, model):
    user_input = user_input.lower().strip()

    if "hello" in user_input or "hi" in user_input:
        return "Hello! I can help predict your loan eligibility. Type 'check eligibility' to begin."
    elif "loan" in user_input or "eligibility" in user_input:
        predict_eligibility(model)
        return "Would you like to check another loan?"
    elif "credit" in user_input:
        return "A positive credit history (1) improves your loan approval chances."
    elif "bye" in user_input or "exit" in user_input:
        return "Goodbye! Have a great day."
    else:
        hint = random.choice(HINTS)
        return f"I'm not sure how to respond to that yet, try saying {hint}."

# -------------------- Main --------------------
def main():
    print("AI Chatbot v3.0 — Loan Eligibility Assistant")
    print("Integrating ML-based predictions from loan dataset.\n")

    model, _ = load_and_train_model()

    while True:
        user_input = input("You: ")
        if user_input.lower() in ["bye", "exit", "quit"]:
            print("Chatbot: Goodbye!")
            break

        response = get_response(user_input, model)
        if response:
            print(f"Chatbot: {response}")

if __name__ == "__main__":
    main()