# Mr Bank
# AI ChatBot V2

import random

KNOWN_TOPICS = {
    "greeting": ["hello", "hi", "hey"],
    "loan": ["loan", "borrow", "credit"],
    "income": ["income", "salary", "earnings"],
    "score": ["credit score", "credit rating", "score"],
    "exit": ["bye", "exit", "quit"]
}

HINTS = [
    "try saying 'hello'",
    "ask me about 'loan eligibility'",
    "ask about 'credit score'",
    "say 'bye' to end the chat"
]

def get_response(user_input):
    """
    Rule-based chatbot with error handling and simple keyword matching.
    """
    user_input = user_input.lower().strip()

    # Greetings
    if any(word in user_input for word in KNOWN_TOPICS["greeting"]):
        return "Hello! How can I help you with your financial queries today?"

    # Loan discussion
    elif any(word in user_input for word in KNOWN_TOPICS["loan"]):
        return ("Our loan recommendations depend on factors like credit score and income. "
                "Could you tell me your income and credit score?")

    # Income
    elif any(word in user_input for word in KNOWN_TOPICS["income"]):
        return "Thanks for sharing. Higher income can improve loan eligibility!"

    # Credit score
    elif any(word in user_input for word in KNOWN_TOPICS["score"]):
        return ("Credit score reflects your repayment reliability. "
                "A score above 600 is generally considered acceptable for most loans.")

    # Exit
    elif any(word in user_input for word in KNOWN_TOPICS["exit"]):
        return "Goodbye! Hope I was able to help."

    # Handle unknown input gracefully
    else:
        hint = random.choice(HINTS)
        return f"I'm not sure how to respond to that yet, {hint}."

def main():
    print("AI Chatbot v2.0")
    print("Type 'exit' to quit.\n")

    while True:
        try:
            user_input = input("You: ").strip()
            if not user_input:
                print("Chatbot: Please type something so I can respond.")
                continue

            if user_input.lower() in KNOWN_TOPICS["exit"]:
                print("Chatbot: Goodbye!")
                break

            response = get_response(user_input)
            print(f"Chatbot: {response}")

        except KeyboardInterrupt:
            print("\nChatbot: Goodbye!")
            break
        except Exception as e:
            print(f"Chatbot: Oops! Something went wrong ({e}).")

if __name__ == "__main__":
    main()