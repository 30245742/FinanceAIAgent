# Mr Bank
# AI ChatBot V1

def get_response(user_input):
    """
    Simple rule-based response system.
    Extend this later with NLP, APIs, or ML models.
    """
    user_input = user_input.lower()

    if "hello" in user_input or "hi" in user_input:
        return "Hello! How can I assist you today?"
    elif "loan" in user_input:
        return "I can help with loan recommendations. Could you tell me your income and credit score?"
    elif "bye" in user_input or "exit" in user_input:
        return "Goodbye! Have a great day."
    else:
        return "I'm not sure how to respond to that yet. I'm still learning!"

def main():
    print("AI Chatbot v1.0")
    print("Type 'exit' to quit.\n")

    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Chatbot: Goodbye!")
            break

        response = get_response(user_input)
        print(f"Chatbot: {response}")

if __name__ == "__main__":
    main()
